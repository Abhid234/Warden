/**
 * content-scripts/instagram.js
 * Instagram changes its DOM/class names often — these selectors target
 * stable structural tags rather than generated class names where possible.
 * Re-check them if Instagram ships a redesign and filtering stops working.
 */

(async function initInstagram() {
  console.info('[Warden] official extension 0.1.3 loaded on Instagram');
  const settings = await getSettings();
  if (!settings.platforms.instagram.enabled) return;

  WardenEngine.startWatching({
    mediaSelector: 'article img, article video',
    textSelector: settings.platforms.instagram.filterText
      ? 'article span[dir="auto"]' // captions + comment text
      : null,
    // Instagram captions commonly occupy the first list item. Treat later
    // list items as comments so a caption semantic match can blur the post.
    commentSelector: 'article ul li:not(:first-child) span[dir="auto"]',
    commentAncestorSelector: 'article ul li:not(:first-child)',
    postSelector: 'article',
    titleSelector: 'article h1,h2,h3,[role="heading"]',
    authorSelector: 'article a[href*="/"]',
  });
})();
